#!/bin/bash


python3 ~/.local/lib/python3.10/site-packages/bubbln/bubbln.py "$@"

